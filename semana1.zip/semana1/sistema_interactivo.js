// Función para solicitar datos al usuario
function solicitarDatos() {
  const nombre = prompt("¿Cuál es tu nombre?");
  const edad = parseInt(prompt("¿Cuántos años tienes?"));
  // Devuelve un objeto con los datos ingresados
  return { nombre, edad };
}

// Función para validar y mostrar mensajes según la edad
function validarEdad(nombre, edad) {
  if (isNaN(edad)) {
    // Si la edad no es un número
    console.error("Error: La edad debe ser un número.");
  } else if (edad < 18) {
    // Si es menor de edad
    alert(`Hola ${nombre}, eres menor de edad. ¡Sigue aprendiendo!`);
  } else {
    // Si es mayor de edad
    alert(`Hola ${nombre}, eres mayor de edad. ¡Sigue creciendo!`);
  }
}

// Ejecutar las funciones
const { nombre, edad } = solicitarDatos();
validarEdad(nombre, edad);
